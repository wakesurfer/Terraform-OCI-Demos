#!/bin/bash -x

# Log everything to the logger -- usually goes to /var/log/messages
exec 1> >(logger -s -t $(basename $0)) 2>&1

echo "################### $(basename $0) begins #####################"
sudo iptables -I BareMetalInstanceServices 8 -d 169.254.169.254/32 -p udp -m udp --dport 123 -m comment --comment "Allow access to OBMCS local NTP service" -j ACCEPT
sudo service iptables save
sudo yum install ntp
sudo ntpdate 169.254.169.254

sudo sed -i -- 's/server 0.rhel.pool.ntp.org/#server 0.rhel.pool.ntp.org/g' /etc/ntp.conf
sudo sed -i -- 's/server 1.rhel.pool.ntp.org/#server 1.rhel.pool.ntp.org/g' /etc/ntp.conf
sudo sed -i -- 's/server 2.rhel.pool.ntp.org/#server 2.rhel.pool.ntp.org/g' /etc/ntp.conf
sudo sed -i -- 's/server 3.rhel.pool.ntp.org/#server 3.rhel.pool.ntp.org/g' /etc/ntp.conf

echo 'server 169.254.169.254 iburst' | sudo tee --append /etc/ntp.conf > /dev/null

sudo chkconfig ntpd on
sudo /etc/init.d/ntpd start

echo "################### $(basename $0) ends #######################"

# To verify:
# ntpq -p  -- Expected output:
#
# remote           refid      st t when poll reach   delay   offset  jitter
# ==============================================================================
# 169.254.169.254 192.168.32.3     2 u    2   64    1    0.338    0.278   0.187
