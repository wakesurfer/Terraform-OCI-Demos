#!/bin/bash -x

awk 'NR==1,/enabled=/{sub(/0/, "1")} 1' /etc/yum.repos.d/public-yum-ol6.repo > a
sudo mv a /etc/yum.repos.d/public-yum-ol6.repo
 
sudo yum -y install gcc libffi-devel python-devel openssl-devel

wget https://bootstrap.pypa.io/get-pip.py
sudo python get-pip.py
 
curl -O https://www.python.org/ftp/python/3.6.0/Python-3.6.0.tgz
tar -xvzf Python-3.6.0.tgz
cd Python-3.6.0
./configure
make
sudo make install
cd ..
 
sudo pip install virtualenv
virtualenv -p /usr/local/bin/python3.6 cli
. cli/bin/activate
pip install oraclebmc-cli
pip install oraclebmc
deactivate

mkdir ~/.oraclebmc