#!/bin/bash -x

# Log everything to the logger -- usually goes to /var/log/messages
exec 1> >(logger -s -t $(basename $0)) 2>&1

sudo firewall-offline-cmd --zone=public --add-service=nfs
sudo yum -y install nfs-utils
sudo service rpcbind start
sudo service nfs start
sudo service nfslock start
sudo chkconfig rpcbind on
sudo chkconfig nfs on
sudo chkconfig nfslock on
#sudo systemctl enable nfs-server.service 
#sudo systemctl start nfs-server.service 
sudo chown nfsnobody:nfsnobody ${nfs_dir}
sudo chmod 777 ${nfs_dir} 
sudo echo '${nfs_dir} ${nfs_cidr}(rw,sync,no_subtree_check) ' > /etc/exports
sudo exportfs -a
#sudo systemctl restart firewalld.service