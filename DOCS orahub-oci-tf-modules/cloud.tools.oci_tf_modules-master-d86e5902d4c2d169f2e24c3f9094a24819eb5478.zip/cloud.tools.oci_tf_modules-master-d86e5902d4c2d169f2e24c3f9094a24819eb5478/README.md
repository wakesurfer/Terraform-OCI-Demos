To create windows instance:

Cannot use packer because of oci limitations:
1) Init script (i.e. cloud-init equivalent) cannot be specified for windows
2) Oracle supplied windows images do not come with winrm enabled over https

Workaround -- Configure a generalized image with these steps:
1) Upload windows_bootstrap.ps1
https://orahub.oraclecorp.com/ateam/cloud.tools.oci_tf_modules/raw/master/windows/windows_bootstrap.ps1
2) Execute script using powershell as Administator (elevated permissions).
3) Follow steps to create generalized image at: 
https://docs.us-phoenix-1.oraclecloud.com/Content/Compute/References/windowsimages.htm

Verication from Windows client for winrm over ssl using windows powershell (elevated permissions):
    $skipCN = New-PSSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck
    $s = New-PSSession 129.213.22.114 -UseSSL -Authentication Basic -Credential opc -SessionOption $skipCN
    Invoke-Command -Session $s -ScriptBlock {Get-Culture}

    Invoke-Command -Session $s -ScriptBlock {dir C:\Users\opc\Desktop}

Verification from Terraform:
    "provisioner" "remote-exec" {
        "connection" = {
        "type"     = "winrm"
        "timeout"  = "5m"
        "host"     = "${self.public_ip}"
        "user"     = "opc"
        "port"     = "5986"
        "https"    = true
        insecure   = true
        "password" = "${var.WIN_opc_password}"
        }

        "inline" = ["echo ${oci_core_instance.WIN_instanceEF.private_ip} >> C:\\ad_ip.txt"]
    }

