# Deploy Vault to AWS

This folder contains a Terraform module for deploying Vault to AWS
(within a VPC). It can be used as-is or can be modified to work in your
scenario, but should serve as a strong starting point for deploying Vault.

See `variables.tf` for a full reference to the parameters that this module
takes and their descriptions.
